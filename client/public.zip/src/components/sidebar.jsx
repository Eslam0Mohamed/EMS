import React, { useState } from 'react'
import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { dummyProfileData } from '../assets/assets'
import { MenuIcon, UserIcon, XIcon } from 'lucide-react'

const sidebar = () => {
    const { pathname } = useLocation()
    const [userName, setUserName] = useState("")
    const [mobileOpen, setMobileOpen] = useState(false)
    useEffect(() => {
        setUserName(dummyProfileData.firstName + " " + dummyProfileData.lastName)
    }, [])
    useEffect(() => {
        setMobileOpen(false)
    }, [pathname])

    const sidebarContent = (
        <>
            <div className='p-5 border-b border-white/6'>
                <div className='flex items-center justify-between'>
                    <div className='flex items-center gap-3'>
                        {/* <UserIcon className='text-white size-7' /> */}
                    </div>
                    <div>
                        <p className='text-white font-semibold text-[13px] '>Empolyee MS</p>
                        <p className='text-[11px] text-slate-500 font-medium'>Management System</p>
                    </div>
                </div>
                <button  onClick={()=>{setMobileOpen(false)}}
                className='lg:hidden text-slate-400 hover:text-white p-1'>
                    <XIcon size={20}/>
                </button>
            </div>
        </>
    )


    return (
        <>
            {/* mobile button */}
            <button onClick={() => { setMobileOpen(true) }} className='lg:hidden fixed top-4 left-4 z-50 p-2 bg-slate-900 text-white 
rounded-lg shadow-lg border border-white/10'>
                <MenuIcon size={20} />
            </button>
            {/* mobile overlay */}
            {mobileOpen && <div onClick={() => { setMobileOpen(false) }} className='lg:hidden fixed top-4 left-4 z-50 backdrop-blur-sm border border-white/10' />}

            {/* aside desktop */}
            <aside className='hidden lg:flex flex-col h-full w-65 text-white shrink-0 border border-white/10 bg-linear-to-b from-slate-900 to-slate-950'>
                {sidebarContent}
            </aside>

            {/* aside mobile */}
            <aside className={`lg:hidden fixed w-72 
     text-white shrink-0 border border-white/10
      bg-linear-to-b from-slate-900 to-slate-950 z-50 flex flex-col transform transition-transform duration-300 inset-0 ${mobileOpen ? "-translate-x-full" : "translate-x-0"} `}>
                {sidebarContent}
            </aside>

        </>
    )
}

export default sidebar
